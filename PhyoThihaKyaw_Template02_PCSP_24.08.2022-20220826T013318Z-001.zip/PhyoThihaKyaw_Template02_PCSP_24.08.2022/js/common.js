$(document).ready(function () {
  $(".sec-fifth-link ul li").heightLine({
      fontSizeCheck: true,
  });

  $("header nav").slideUp();
  $(".menu-trigger").click(function () {
    $(this).toggleClass("active");
    if ($(this).hasClass("active")) {
      $("header nav").slideDown();
    }

    else {
      $("header nav").slideUp();
    }
});
})